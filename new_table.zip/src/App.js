import React from 'react';
import { data } from './data';
import './App.css';

const App = () => {
  return (
    <div style={{ width: 900, height: 800, overflow: 'scroll' }}>
      <table border='1' cellSpacing={0} cellPadding={12}>
        <tr>
          <td className='sticky-col first-col' rowSpan={1}></td>
          <th className='sticky-col second-col' colSpan='1' scope='col'>
            <img
              src='https://cdn.mos.cms.futurecdn.net/5StAbRHLA4ZdyzQZVivm2c.jpg'
              style={{ width: '100px' }}
              alt='walmart'
            />
            <div>
              <a href='https://www.walmart.com/'>https://www.walmart.com/</a>
            </div>
          </th>
          <th colSpan='5' scope='col'>
            <img
              src='https://i0.wp.com/www.dafontfree.co/wp-content/uploads/2021/11/Amazon-Logo-Font-1-scaled.jpg?fit=2560%2C1578&ssl=1'
              style={{ width: '100px' }}
              alt='amazon'
            />
            <div>
              <a href='https://www.amazon.in/'>https://www.amazon.in/</a>
            </div>
          </th>
        </tr>

        <tr>
          <td rowSpan={1} className='sticky-col first-col'></td>

          {data.map(d => {
            return (
              <th scope='col' className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>
                <div>{d.itemId}</div>
                <img src={d.image} style={{ width: '200px' }} alt='ring' />
              </th>
            );
          })}
        </tr>

        <tr>
          <th className='sticky-col first-col' scope='row'>
            Match Score
          </th>
          {data.map(d => {
            return (
              <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>
                {d.score ? (
                  <span>
                    {d.score}
                    <button style={{ marginLeft: '10rem' }}>Add Like match</button>
                  </span>
                ) : (
                  '-'
                )}
              </td>
            );
          })}
        </tr>

        <tr>
          <th scope='row' className='sticky-col first-col'>
            Item ID
          </th>
          {data.map(d => {
            return <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>{d.itemId}</td>;
          })}
        </tr>

        <tr>
          <th scope='row' className='sticky-col first-col'>
            Product Title
          </th>
          {data.map(d => {
            return <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>{d.productTitle}</td>;
          })}
        </tr>
        <tr>
          <th scope='row' className='sticky-col first-col'>
            Description
          </th>
          {data.map(d => {
            return <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>{d.desc}</td>;
          })}
        </tr>
        <tr>
          <th scope='row' className='sticky-col first-col'>
            Product Info
          </th>
          {data.map(d => {
            return <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>{d.productInfo}</td>;
          })}
        </tr>
        <tr>
          <th scope='row' className='sticky-col first-col'>
            Brand
          </th>
          {data.map(d => {
            return <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>{d.brand ? d.brand : '-'}</td>;
          })}
        </tr>
        <tr>
          <th scope='row' className='sticky-col first-col'>
            Model
          </th>
          {data.map(d => {
            return <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>{d.model}</td>;
          })}
        </tr>
        <tr>
          <th scope='row' className='sticky-col first-col'>
            MPN
          </th>
          {data.map(d => {
            return <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>{d.mpn}</td>;
          })}
        </tr>
        <tr>
          <th scope='row' className='sticky-col first-col'>
            UPC
          </th>
          {data.map(d => {
            return <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>{d.upc ? d.upc : '-'}</td>;
          })}
        </tr>
        <tr>
          <th scope='row' className='sticky-col first-col'>
            GTIN
          </th>
          {data.map(d => {
            return <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>{d.gtin}</td>;
          })}
        </tr>
        <tr>
          <th scope='row' className='sticky-col first-col'>
            Price
          </th>
          {data.map(d => {
            return <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>{d.price}</td>;
          })}
        </tr>
        <tr>
          <th scope='row' className='sticky-col first-col'>
            Variant
          </th>
          {data.map(d => {
            return (
              <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>{d.variant ? d.variant : '-'}</td>
            );
          })}
        </tr>
        <tr>
          <th scope='row' className='sticky-col first-col'>
            Super Department
          </th>
          {data.map(d => {
            return <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>{d.superDept}</td>;
          })}
        </tr>
        <tr>
          <th scope='row' className='sticky-col first-col'>
            Department
          </th>
          {data.map(d => {
            return <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>{d.dept}</td>;
          })}
        </tr>
        <tr>
          <th scope='row' className='sticky-col first-col'>
            Category
          </th>
          {data.map(d => {
            return <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>{d.category}</td>;
          })}
        </tr>
        <tr>
          <th scope='row' className='sticky-col first-col'>
            Sub Category
          </th>
          {data.map(d => {
            return <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>{d.subCategory}</td>;
          })}
        </tr>
        <tr>
          <th scope='row' className='sticky-col first-col'>
            URL
          </th>
          {data.map(d => {
            return (
              <td className={d.cat === 'walmart' ? 'sticky-col second-col' : ''}>
                <a href={d.url}>{d.url}</a>
              </td>
            );
          })}
        </tr>
      </table>
    </div>
  );
};

export default App;
