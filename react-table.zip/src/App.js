import React from 'react';
import { data } from './data';
import './App.css';

const App = () => {
  return (
    <div style={{ display: 'flex', justifyContent: 'center' }}>
      <table border='1' cellSpacing={0} cellPadding={12}>
        <tr>
          <td className='sticky' rowSpan={1}></td>
          <th className='sticky' colSpan='1' scope='col'>
            <img
              src='https://cdn.mos.cms.futurecdn.net/5StAbRHLA4ZdyzQZVivm2c.jpg'
              style={{ width: '100px' }}
              alt='walmart'
            />
            <div>
              <a href='https://www.walmart.com/'>https://www.walmart.com/</a>
            </div>
          </th>
          <th colSpan='3' scope='col'>
            <img
              src='https://i0.wp.com/www.dafontfree.co/wp-content/uploads/2021/11/Amazon-Logo-Font-1-scaled.jpg?fit=2560%2C1578&ssl=1'
              style={{ width: '100px' }}
              alt='amazon'
            />
            <div>
              <a href='https://www.amazon.in/'>https://www.amazon.in/</a>
            </div>
          </th>
        </tr>

        <tr>
          <td rowSpan={1}></td>

          {data.map(d => {
            return (
              <th scope='col'>
                <div>{d.itemId}</div>
                <img src={d.image} style={{ width: '200px' }} alt='ring' />
              </th>
            );
          })}
        </tr>

        <tr>
          <th className='left' scope='row'>
            Match Score
          </th>
          {data.map(d => {
            return (
              <td>
                {d.score ? (
                  <span>
                    {d.score}
                    <button style={{ marginLeft: '10rem' }}>Add Like match</button>
                  </span>
                ) : (
                  '-'
                )}
              </td>
            );
          })}
        </tr>

        <tr>
          <th scope='row'>Item ID</th>
          {data.map(d => {
            return <td>{d.itemId}</td>;
          })}
        </tr>

        <tr>
          <th scope='row'>Product Title</th>
          {data.map(d => {
            return <td>{d.productTitle}</td>;
          })}
        </tr>
        <tr>
          <th scope='row'>Description</th>
          {data.map(d => {
            return <td>{d.desc}</td>;
          })}
        </tr>
        <tr>
          <th scope='row'>Product Info</th>
          {data.map(d => {
            return <td>{d.productInfo}</td>;
          })}
        </tr>
        <tr>
          <th scope='row'>Brand</th>
          {data.map(d => {
            return <td>{d.brand ? d.brand : '-'}</td>;
          })}
        </tr>
        <tr>
          <th scope='row'>Model</th>
          {data.map(d => {
            return <td>{d.model}</td>;
          })}
        </tr>
        <tr>
          <th scope='row'>MPN</th>
          {data.map(d => {
            return <td>{d.mpn}</td>;
          })}
        </tr>
        <tr>
          <th scope='row'>UPC</th>
          {data.map(d => {
            return <td>{d.upc ? d.upc : '-'}</td>;
          })}
        </tr>
        <tr>
          <th scope='row'>GTIN</th>
          {data.map(d => {
            return <td>{d.gtin}</td>;
          })}
        </tr>
        <tr>
          <th scope='row'>Price</th>
          {data.map(d => {
            return <td>{d.price}</td>;
          })}
        </tr>
        <tr>
          <th scope='row'>Variant</th>
          {data.map(d => {
            return <td>{d.variant ? d.variant : '-'}</td>;
          })}
        </tr>
        <tr>
          <th scope='row'>Super Department</th>
          {data.map(d => {
            return <td>{d.superDept}</td>;
          })}
        </tr>
        <tr>
          <th scope='row'>Department</th>
          {data.map(d => {
            return <td>{d.dept}</td>;
          })}
        </tr>
        <tr>
          <th scope='row'>Category</th>
          {data.map(d => {
            return <td>{d.category}</td>;
          })}
        </tr>
        <tr>
          <th scope='row'>Sub Category</th>
          {data.map(d => {
            return <td>{d.subCategory}</td>;
          })}
        </tr>
        <tr>
          <th scope='row'>URL</th>
          {data.map(d => {
            return (
              <td>
                <a href={d.url}>{d.url}</a>
              </td>
            );
          })}
        </tr>
      </table>
    </div>
  );
};

export default App;
